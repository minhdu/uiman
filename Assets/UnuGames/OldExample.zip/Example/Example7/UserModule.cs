﻿using UnityEngine;
using System.Collections;
using UnuGames;

public class UserModule : UIManModule<UserModel> {

}
