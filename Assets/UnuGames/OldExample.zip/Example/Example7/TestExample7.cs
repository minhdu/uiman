﻿using UnityEngine;
using System.Collections;
using UnuGames;

public class TestExample7 : MonoBehaviour {

	// Use this for initialization
	void Start () {
		UIMan.Instance.ShowScreen<UIExample7> ();
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
