﻿using UnityEngine;
using System.Collections;
using UnuGames;

public class TestExample4 : MonoBehaviour {

	// Use this for initialization
	void Start () {
		UIMan.Instance.ShowScreen<UIExample3> ();
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
