﻿using UnityEngine;
using System.Collections;

public class Friend {

	public string Name;
	public int Age;
}
